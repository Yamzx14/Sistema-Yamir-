﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Clases
{
    internal class clsRoles
    {
        private byte id;
        private string nombre;

        // Método Constructor Busqueda de toda la informacion de la tabla de Roles
        public clsRoles()
        {
        }
        // método constructor para grabar y modificar
        public clsRoles(byte id, string nombre)
        {
            this.id = id;
            this.nombre = nombre;
        }
        // método constructor para consulta individual
        public clsRoles(byte id)
        {
            this.id = id;
        }

        public string GRABAR()
        {
            return (" insert into Rol values ('" + this.id + "','" + this.nombre + "')");
        }
        public string CONSULTARI()
        {
            return (" SELECT * FROM  Rol WHERE id= '" + this.id + "'");
        }
        public string modificar()
        {
            return (" update Rol set  nombre ='" + this.nombre + "' WHERE id= '" + this.id + "'");
        }
        public string consultageneral()
        {
            return (" SELECT id as id,nombre as nombre FROM  Rol");
        }
        public string consecutivo()
        {
            return ("select count(*) +1 as folio from Rol");
        } 
    }
}
