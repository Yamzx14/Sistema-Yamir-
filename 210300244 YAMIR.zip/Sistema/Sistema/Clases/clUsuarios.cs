﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Clases
{
    internal class clUsuarios
    {
        private string USU_LOGIN;
        private string USU_PASS;
        public string USU_NOMBRE;

        public clUsuarios(string uSU_LOGIN, string uSU_PASS)
        {
            USU_LOGIN = uSU_LOGIN;
            USU_PASS = uSU_PASS;
        }

        public string CONSULTARI()
        {
            return ("SELECT nombre,contraseña FROM usuario WHERE nombre = '" + this.USU_LOGIN + "' and contraseña = dbo.MD5('" + this.USU_PASS + "')");
        }
    }
}
