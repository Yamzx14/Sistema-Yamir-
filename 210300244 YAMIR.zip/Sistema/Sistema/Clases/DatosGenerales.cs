﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Clases
{
    class DatosGenerales
    {
        private string nombre;
        private string direccion;
        private string telefono;
        private string gerente;

        public DatosGenerales(string nombre, string direccion, string telefono, string gerente)
        {
            this.nombre = nombre;
            this.direccion = direccion;
            this.telefono = telefono;
            this.gerente = gerente;
        }
        public DatosGenerales()
        {
        }

        public string grabar()
        {
            return (" insert into generales values ('" + this.nombre + "','" + this.direccion + "','" + this.telefono + "','" + this.gerente + "')");
        }
        public string cosnultar()
        {
            return (" SELECT * FROM  DatosGenerales WHERE Nombre = '" + this.nombre + "'");
        }
        public string modificar()
        {
            return (" update DatosGenerales set  direccion ='" + this.direccion + "', Telefono ='" + this.telefono + "', Gerente ='" + this.gerente + "' WHERE Nombre = '" + this.nombre + "'");
        }
        public string consecutivo()
        {
            return ("SELECT COUNT(*) + 1 AS folio from DatosGenerales");
        }
        public string ConsultaGeneral()
        {
            return (" SELECT Nombre as Nombre , Direccion as Direccion, Telefono as Telefono, Gerente as Gerente FROM  DatosGenerales");
        }
    }
}
