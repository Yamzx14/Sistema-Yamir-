﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema.Clases
{
    class usuario
    {
        private int id_usuario;
        private string nombre;
        private string contraseña;
        private byte rol;

        public usuario(int id_usuario, string nombre, string contraseña,byte rol)
        {
            this.id_usuario = id_usuario;
            this.nombre = nombre;
            this.contraseña = contraseña;
            this.rol = rol;
        }
        public usuario(int id_usuario)
        {
            this.id_usuario = id_usuario;
        }
        public usuario()
        {
        }
        public string grabar()
        {
            return (" insert into usuario values ('" + this.id_usuario + "','" + this.nombre + "','" + this.contraseña + "','" + this.rol + "')");
        }
        public string consultaria()
        {
            return (" SELECT * FROM  usuario WHERE id_usuario= '" + this.id_usuario + "'");
        }
        public string modificar()
        {
            return (" update Usuario set  id_usuario ='" + this.id_usuario + "', Nombre ='" + this.nombre + "', Contraseña ='" + this.contraseña + "', Rol ='" + this.rol + "'");
        }
        public string consultageneral()
        {
            return (" SELECT id_usuario as id_usuario , nombre as nombre, contraseña as contraseña , rol as rol FROM  usuario");
        }
        public string consecutivo()
        {
            return ("select count(*) + 1 as folio from Usuario");
        }
       
    }
}
