﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Sistema
{
    public partial class frmUsuarios : Form
    {
        public frmUsuarios()
        {
            InitializeComponent();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmUsuarios_Load(object sender, EventArgs e)
        {
            cargarroles();
            cargarfolio();
        }
        private void cargarroles()
        {
            DataSet ds = new DataSet();
            Clases.clsRoles s = new Clases.clsRoles();
            Clases.conexion c = new Clases.conexion(s.consultageneral());
            ds = c.consultar();
            cdroles.DataSource = ds.Tables[0];
            cdroles.DisplayMember = ds.Tables[0].Columns["nombre"].ToString();
            cdroles.ValueMember = ds.Tables[0].Columns["id"].ToString();
        }

        /*byte puesto = 0;
              puesto = byte.parse
               (xmbpuesto.selectedvalue.tostring)

        byte */
        public string consultafeneral()
        {
            return ("select * ");
        }

        Clases.usuario G;
        private void busca()
        {
            try
            {
                G = new Clases.usuario();
                Clases.conexion con = new Clases.conexion();
                if (con.Execute(G.consultageneral(), 0) == true)
                {
                    if (con.FieldValue != "")
                    {
                        textBox1.Text = con.FieldValue;
                        consultar();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message);
            }
        }


        Clases.conexion c;
        Clases.usuario B;
        private void consultar()
        {
            if (!(textBox1.Text == ""))
            {
                try
                {
                    B = new Clases.usuario(Convert.ToInt32(textBox1.Text));
                    DataSet ds = new DataSet();
                    c = new Clases.conexion(B.consultaria());
                    ds = c.consultar();
                    if (ds.Tables["Tabla"].Rows.Count > 0)
                    {
                        textBox1.Text = ds.Tables["Tabla"].Rows[0]["id_usuario"].ToString();
                        textBox4.Text = ds.Tables["Tabla"].Rows[0]["Nombre"].ToString();
                        textBox2.Text = ds.Tables["Tabla"].Rows[0]["Contraseña"].ToString();
                        cdroles.Text = ds.Tables["Tabla"].Rows[0]["Rol"].ToString();
                    }
                    else

                        MessageBox.Show("No Existe este dato");
                    textBox4.Focus();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex.Message);
                }
            }
        }

        void cargarfolio()
        {
            B = new Clases.usuario();
            DataSet ds = new DataSet();
            c = new Clases.conexion(B.consecutivo());
            ds = c.consultar();
            if (ds.Tables["Tabla"].Rows.Count > 0)
            {
                textBox1.Text = ds.Tables["Tabla"].Rows[0]["folio"].ToString();
            }
        }

        private void graba()
        {
            Clases.usuario B = new Clases.usuario(Convert.ToInt32(textBox1.Text));
            DataSet ds = new DataSet();
            c = new Clases.conexion(B.consultaria());
            ds = c.consultar();
            G = new Clases.usuario(Convert.ToInt32(textBox1.Text), textBox4.Text, Clases.Contraseña.Encrypt.GetMD5(textBox2.Text), byte.Parse(cdroles.SelectedValue.ToString()));//, true
            if (ds.Tables["Tabla"].Rows.Count > 0)
                c = new Clases.conexion(G.modificar());
            else
                c = new Clases.conexion(G.grabar());
            MessageBox.Show(c.ejecutar());
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            busca();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if ((textBox2.Text == "") || (textBox3.Text == "") || (textBox4.Text == ""))
            {
                MessageBox.Show("Falta de rellenar datos");
            }
            else
            {
                if (textBox2.Text == textBox3.Text)
                {
                    graba();
                    cargarfolio();
                    textBox4.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                }
                else
                {
                    MessageBox.Show("La contraseña no conside");
                }
            }
        }
    }

}