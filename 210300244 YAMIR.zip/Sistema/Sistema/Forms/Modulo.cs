﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Sistema.Forms
{
    public partial class Modulo : Form
    {
        public Modulo()
        {
            InitializeComponent();
        }

        private void Modulo_Load(object sender, EventArgs e)
        {
            cargarfolio();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (TXTNOMBREROL.Text == "")
            {
                MessageBox.Show("Falta de rellenar datos");
            }
            else
            {
                graba();
                cargarfolio();
                TXTNOMBREROL.Clear();
            }
        }

        Clases.Modulo G;
        private void busca()
        {
            try
            {
                G = new Clases.Modulo();
                Clases.conexion con = new Clases.conexion();
                if (con.Execute(G.consultageneral(), 0) == true)
                {
                    if (con.FieldValue != "")
                    {
                        TXTCLAVE.Text = con.FieldValue;
                        consultar();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message);
            }
        }

        Clases.conexion c;
        Clases.Modulo B;
        private void consultar()
        {
            if (!(TXTCLAVE.Text == ""))
            {
                try
                {
                    B = new Clases.Modulo(byte.Parse(TXTCLAVE.Text));
                    DataSet ds = new DataSet();
                    c = new Clases.conexion(B.CONSULTARI());
                    ds = c.consultar();
                    if (ds.Tables["Tabla"].Rows.Count > 0)
                    {
                        TXTCLAVE.Text = ds.Tables["Tabla"].Rows[0]["ID"].ToString();
                        TXTNOMBREROL.Text = ds.Tables["Tabla"].Rows[0]["NOMBRE"].ToString();


                    }
                    else

                        MessageBox.Show("No Existe este dato");
                    TXTNOMBREROL.Focus();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex.Message);
                }
            }
        }

        void cargarfolio()
        {
            B = new Clases.Modulo();
            DataSet ds = new DataSet();
            c = new Clases.conexion(B.consecutivo());
            ds = c.consultar();
            if (ds.Tables["Tabla"].Rows.Count > 0)
            {
                TXTCLAVE.Text = ds.Tables["Tabla"].Rows[0]["folio"].ToString();
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            busca();
        }

        private void graba()
        {
            Clases.Modulo B = new Clases.Modulo(byte.Parse(TXTCLAVE.Text));
            DataSet ds = new DataSet();
            c = new Clases.conexion(B.CONSULTARI());
            ds = c.consultar();
            G = new Clases.Modulo(byte.Parse(TXTCLAVE.Text), TXTNOMBREROL.Text);//, true
            if (ds.Tables["Tabla"].Rows.Count > 0)
                c = new Clases.conexion(G.modificar());
            else
                c = new Clases.conexion(G.GRABAR());
            MessageBox.Show(c.ejecutar());
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Close();    
        }
    }
}
