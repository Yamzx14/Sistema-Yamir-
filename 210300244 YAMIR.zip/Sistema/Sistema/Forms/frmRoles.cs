﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.ReportAppServer;
using CrystalDecisions.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;
using Table = CrystalDecisions.CrystalReports.Engine.Table;

namespace Sistema.Forms
{
    public partial class frmRoles : Form
    {
        public frmRoles()
        {
            InitializeComponent();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            busca();
        }
        Clases.clsRoles G;
        private void busca()
        {
            try
            {
                G = new Clases.clsRoles();
                Clases.conexion con = new Clases.conexion();
                if (con.Execute(G.consultageneral(), 0) == true)
                {
                    if (con.FieldValue != "")
                    {
                        TXTCLAVE.Text = con.FieldValue;
                        consultar();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message);
            }
        }
        Clases.conexion c;
        Clases.clsRoles B;
        private void consultar()
        {
            if (!(TXTCLAVE.Text == ""))
            {
                try
                {
                    Clases.clsRoles B = new Clases.clsRoles(byte.Parse(TXTCLAVE.Text));
                    DataSet ds = new DataSet();
                    c = new Clases.conexion(B.CONSULTARI());
                    ds = c.consultar();
                    if (ds.Tables["Tabla"].Rows.Count > 0)
                    {
                        TXTCLAVE.Text = ds.Tables["Tabla"].Rows[0]["Id"].ToString();
                        TXTNOMBREROL.Text = ds.Tables["Tabla"].Rows[0]["nombre"].ToString();
                        //TXTCHO_MODELO.Text = ds.Tables["Tabla"].Rows[0]["CHO_MODELO"].ToString();
                        //TXTCHO_TELEFONO.Text = ds.Tables["Tabla"].Rows[0]["CHO_TELEFONO"].ToString();
                        //TXTCHO_COLOR.Text = ds.Tables["Tabla"].Rows[0]["CHO_COLOR"].ToString();
                        // TXTLOT_LOTE.Select(TXTLOT_LOTE.Text.Length, 0);


                    }
                    else

                        MessageBox.Show("No Existe este dato");
                    TXTCLAVE.Focus();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex.Message);
                }

            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            graba();
            cargarfolio();
            TXTNOMBREROL.Clear();
        }
        private void graba()
        {
            Clases.clsRoles B = new Clases.clsRoles(byte.Parse(TXTCLAVE.Text));
            DataSet ds = new DataSet();
            c = new Clases.conexion(B.CONSULTARI());
            ds = c.consultar();
            G = new Clases.clsRoles(byte.Parse(TXTCLAVE.Text), TXTNOMBREROL.Text);
            if (ds.Tables["Tabla"].Rows.Count > 0)
                c = new Clases.conexion(G.modificar());
            else
                c = new Clases.conexion(G.GRABAR());
            MessageBox.Show(c.ejecutar());
        }

        private void sALIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
              Close();
        }

        private void frmRoles_Load(object sender, EventArgs e)
        {
            cargarfolio();
        }
        void cargarfolio()
        {
            B = new Clases.clsRoles();
            DataSet ds = new DataSet();
            c = new Clases.conexion(B.consecutivo());
            ds = c.consultar();
            if (ds.Tables["Tabla"].Rows.Count > 0)
            {
                TXTCLAVE.Text = ds.Tables["Tabla"].Rows[0]["folio"].ToString();
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            Catalogos.Plantilla x = new Catalogos.Plantilla();

            Catalogos.rptReportes orptPrueba;
            ConnectionInfo oConexInfo;
            Tables oListaTablas;
            TableLogOnInfo oTablaConexInfo;
            oConexInfo = new ConnectionInfo();
            oConexInfo.ServerName = Clases.globales.server;
            oConexInfo.DatabaseName = Clases.globales.dbn;

            Boolean IntegratedSecurity = false;
            oConexInfo.IntegratedSecurity = IntegratedSecurity;
            oConexInfo.UserID = Clases.globales.userID;
            oConexInfo.Password = Clases.globales.password;
            oConexInfo.DatabaseName = Clases.globales.dbn;
            oConexInfo.Type = ConnectionInfoType.Query;

            //orptPrueba = new rptventasperiodo();
            orptPrueba = new Catalogos.rptReportes();
            oListaTablas = orptPrueba.Database.Tables;
            foreach (Table roTabla in oListaTablas)
            {
                oTablaConexInfo = roTabla.LogOnInfo;
                oTablaConexInfo.ConnectionInfo = oConexInfo;
                roTabla.ApplyLogOnInfo(oTablaConexInfo);
            }

            DateTimeFormatInfo dtinfo = new CultureInfo("es-ES", false).DateTimeFormat;


          /* if (!(string.IsNullOrEmpty(txtboletai.Text)))
                orptPrueba.SetParameterValue("@FOLIOBOLETA", int.Parse(txtboletai.Text));
            else

                MessageBox.Show("Por favor introduzca el Número de Boleta", "Advertencia",
                MessageBoxButtons.OK,
                MessageBoxIcon.Exclamation,
                MessageBoxDefaultButton.Button1);*/

            x.crystalReportViewer1.ReportSource = orptPrueba;
            x.ShowDialog();
            // Set cursor as default arrow
            Cursor.Current = Cursors.Default;
        }
    }
}
