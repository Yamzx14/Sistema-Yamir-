﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        Clases.conexion c;
        Clases.clUsuarios CU;

        private void button2_Click(object sender, EventArgs e)
        {
            ingresar();
        }

        private void ingresar()
        {
            Clases.clUsuarios u = new Clases.clUsuarios(textBox1.Text, textBox2.Text);
            DataSet ds = new DataSet();
            c = new Clases.conexion(u.CONSULTARI());
            ds = c.consultar();
            if (ds.Tables["Tabla"].Rows.Count > 0)
            {
                Menu x = new Menu();
                x.Show(); this.Hide();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectas", "Verifique", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
